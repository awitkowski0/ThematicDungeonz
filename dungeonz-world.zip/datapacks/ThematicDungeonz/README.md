# Thematic Datapack

## DungeonZ integration

https://github.com/Globox1997/DungeonZ/tree/1.20

## Installing/Testing

https://playfulprogramming.com/posts/minecraft-data-packs-introduction#Installing--testing-the-data-pack

Just make sure you're doing this on a world with fabric 1.20.1, Thematic, & DungeonZ of course.